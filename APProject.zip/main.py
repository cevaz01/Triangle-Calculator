import math

notTriangle = False

#finds distance between two points to interpret as side lengths
def distance(pointA, pointB):
    distance = math.sqrt(math.pow((pointA[0] - pointB[0]), 2) + math.pow((pointA[1] - pointB[1]), 2))
    return distance
    
def area(a, b, c):
    s = (c + a + b)/2
    return round(math.sqrt(s*(s-c)*(s-a)*(s-b)), 3)
    
def midpoint(pointA, pointB):
    midpointX = (pointA[0] + pointB[0])/2
    midpointY = (pointA[1] + pointB[1])/2
    return (round(midpointX, 3), round(midpointY, 3))

#angles measured in degrees
def angle(pointA, pointB, pointC):
    A = (math.pow(distance(pointA, pointC), 2) + math.pow(distance(pointA, pointB), 2) - math.pow(distance(pointB, pointC), 2))/(2*distance(pointA, pointC)*distance(pointA, pointB))
    A = math.acos(A)
    return A*(180/math.pi)

#ensures user input is numeric
def numericcheck(userinput):
    while True:
        try:
            float(userinput)
            break
        except:
            userinput = input("Please input a number.\n")
            continue
    return float(userinput)

#inteprets integers for more naturally readable output
def intcheck(number):
    if number.is_integer() == True:
        number = int(number)
    else:
        number = number
    return number

def round3(number):
    number = round(number, 3)
    return number

print("Welcome to One-Stop Triangle Stop!")
pointAX = numericcheck(input("Please enter the X value of your first point: "))
pointAY = numericcheck(input("Please enter the Y value of your first point: "))
pointBX = numericcheck(input("Please enter the X value of your second point: "))
pointBY = numericcheck(input("Please enter the Y value of your second point: "))
pointCX = numericcheck(input("Please enter the X value of your third point: "))
pointCY = numericcheck(input("Please enter the Y value of your third point: "))

#collapsing individual data points into an array
pointA = (pointAX, pointAY)
pointB = (pointBX, pointBY)
pointC = (pointCX, pointCY)

#finding sidelengths
c = distance(pointA, pointB)
a = distance(pointB, pointC)
b = distance(pointA, pointC)

#finding angle measurements with the traditional naming sense (angle A is opposite side a)
A = angle(pointA, pointB, pointC)
B = angle(pointB, pointA, pointC)
C = angle(pointC, pointA, pointB)

Area = area(a, b, c)

#quits program if input is not a triangle
if A == 180 or B == 180 or C == 180:
    notTriangle = True
    print("This is a straight line, not a triangle.")
    raise SystemExit(0)

print("\nSidelengths:\nSide a: " + str(intcheck(round(a, 3))) + "\nSide b: " + str(intcheck(round(b, 3))) + "\nSide c: " + str(intcheck(round(c, 3))))

print("\nMidpoints:\nMidpoint of side a: " + str(midpoint(pointB, pointC)) + "\nMidpoint of side b: " + str(midpoint(pointA, pointC)) + "\nMidpoint of side c: " + str(midpoint(pointA, pointB)))

print("\nAngles:\nAngle A: " + str(intcheck(round(A, 3))) + "\nAngle B: " + str(intcheck(round(B, 3))) + "\nAngle C: " + str(intcheck(round(C, 3))))

print("\nArea: " + str(Area))

print("")
A = round3(A)
B = round3(B)
C = round3(C)

if A > 90 and A < 180 or B > 90 and B < 180 or C > 90 and C < 180:
    angleType = "obtuse"
elif A == 90 or B == 90 or C == 90:
    angleType = "right"
else:
    angleType = "acute"

if round(a, 3) == round(b, 3) and round(b, 3) == round(c, 3):
    sideType = "equilateral"
elif round(a, 3) == round(b, 3) or round(b, 3) == round(c, 3) or round(a, 3) == round(c, 3):
    sideType = "isosceles"
else:
    sideType = "scalene"

if angleType == "right":
    print("This is a " + angleType + " " + sideType + " triangle.")
else:
    print("This is an " + angleType + " " + sideType + " triangle.")